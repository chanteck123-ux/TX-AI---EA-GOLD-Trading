# GSM GOLD 3-SOP EA V4.00 Champion

当前锁定版本：

| Champion | Version | Net Profit USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| Scalping M5 | SC-S20 | 53.47 | 3.35% | 1.72 | 27 | 66.67% | 0 |
| Intraday M30 | IN-I32 | 94.60 | 2.76% | 8.88 | 16 | 93.75% | 0 |
| Swing | SW-W37 | 169.09 | 9.84% | 无毛亏 | 7 | 100.00% | 0 |
| Combined | C-C01 | 317.16 | 8.50% | 4.66 | 50 | 80.00% | 0 |

以上首页指标使用 Tradona `2025-02-01` 至 `2026-08-26` LONG100 公平区间、USD 500、固定 0.01 手、100% Real Tick。FxPro 从 `2026-01-05` 才有共同历史，完整结果请打开 `FINAL_REPORT_CN.html`。

## 使用文件

- EA 源码：`CODE/GSM_Gold_3SOP_EA_CHAMPION.mq5`
- 已编译 EA：`BIN/GSM_Gold_3SOP_EA_CHAMPION.ex5`
- FxPro Combined SET：`SETS/FxPro/GSM_Gold_3SOP_EA_COMBINED_CHAMPION.set`
- Tradona Combined SET：`SETS/Tradona/GSM_Gold_3SOP_EA_COMBINED_CHAMPION.set`
- 回测配置：`CONFIG/`
- 原始 MT5 报告：`REPORTS/COMBINED/`
- 三策略独立证据：`BEST_SCALPING/`、`BEST_INTRADAY/`、`BEST_SWING/`
- V3.00 / V3.10 对照：`RESEARCH/FINAL_CHAMPION_VS_V300_V310.csv`
- 历史基准原始摘要：`reference/published/`
- 全文件校验：`SHA256.txt`

## 重要限制

这是研究/回测 Champion，不是实盘盈利承诺，也不是实盘授权。C-C01 相比 V3.00 的综合质量更强；V3.10 虽然净利润和交易数更高，但共同区间回撤达到 31.67% 至 38.88%，触发 DD 风险否决，而且包含当前制度不采用的强制 Coverage 交易。Swing 样本只有 7 笔；Tradona 2026 利润受一笔高波动 Swing 交易影响较大，该交易在最小 0.01 手下初始 SL 风险为 9.93%。建议先在 FxPro 与 Tradona Demo 前向运行，核对符号规格、成交、滑点和风险后再决定下一步。
