# C-C01 Combined 3-SOP Champion Report

Date: `2026-09-03`

Status: `LOCKED RESEARCH / BACKTEST CHAMPION`

This lock combines the three independently locked strategy Champions without changing their entry or exit rules:

- Scalping M5: `SC-S20`
- Intraday M30: `IN-I32`
- Swing D1/H4/M30: `SW-W37`

It is not live-trading authorization.

## Portfolio configuration

- All three strategies: `ON`, independent `OR` execution
- Fixed lot: `0.01` per strategy
- Per-strategy open positions: maximum `1`
- Total open positions: maximum `3`
- Total open SL risk: maximum `10%`
- Starting capital: `USD 500`
- Account type: hedging required
- Confidence filters: score/display only, not hard blockers
- MT5 model: `4`, `100% real quotes`

## Accepted account-level evidence

| Segment | Broker | Symbol | Period | Net Profit USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| TRAIN 2025 | Tradona | XAUUSD.tm | 2025-02-01 to 2025-12-31 | 98.79 | 16.94 USD / 3.20% | 3.74 | 25 | 84.00% | 0 |
| TRAIN 2026 | FxPro | GOLD | 2026-01-05 to 2026-04-30 | 11.27 | 15.95 USD / 3.10% | 1.44 | 8 | 62.50% | 0 |
| TRAIN 2026 | Tradona | XAUUSD.tm | 2026-01-05 to 2026-04-30 | 156.94 | 61.36 USD / 10.08% | 6.98 | 9 | 66.67% | 0 |
| OOS 2026 | FxPro | GOLD | 2026-05-01 to 2026-08-26 | 68.57 | 57.69 USD / 9.89% | 5.08 | 15 | 86.67% | 0 |
| OOS 2026 | Tradona | XAUUSD.tm | 2026-05-01 to 2026-08-26 | 33.25 | 59.68 USD / 10.24% | 2.37 | 12 | 75.00% | 0 |
| FULL 2026 | FxPro | GOLD | 2026-01-05 to 2026-08-26 | 93.71 | 57.69 USD / 9.48% | 3.21 | 25 | 80.00% | 0 |
| FULL 2026 | Tradona | XAUUSD.tm | 2026-01-05 to 2026-08-26 | 204.28 | 61.36 USD / 10.08% | 5.04 | 23 | 73.91% | 0 |
| LONG100 | Tradona | XAUUSD.tm | 2025-02-01 to 2026-08-26 | 317.16 | 61.36 USD / 8.50% | 4.66 | 50 | 80.00% | 0 |

All eight segments are profitable. Both brokers pass OOS, and `OrdersRequested = OrdersFilled` in every run.

## V3.00 / V3.10 published Combined benchmark

The published old Combined packages do not have the exact current split boundary. V3.00 covers `2026-01-05 to 2026-08-20`; V3.10 common covers `2026-01-05 to 2026-08-27`; C-C01 FULL covers `2026-01-05 to 2026-08-26`. V3.10 also forces daily Intraday and weekly Swing Coverage orders, while C-C01 keeps only the three independent core SOPs. The table is therefore a required historical directional comparison, not a strict same-configuration promotion test.

| Version | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| V3.00 published | FxPro | 90.45 | 9.32% | 3.13 | 25 | 80.00% | 0 |
| C-C01 | FxPro | 93.71 | 9.48% | 3.21 | 25 | 80.00% | 0 |
| V3.00 published | Tradona | 53.87 | 10.29% | 2.07 | 22 | 72.73% | 0 |
| C-C01 | Tradona | 204.28 | 10.08% | 5.04 | 23 | 73.91% | 0 |
| V3.10 published, Coverage ON | FxPro | 511.37 | 38.88% | 1.31 | 223 | 54.71% | 0 |
| C-C01 | FxPro | 93.71 | 9.48% | 3.21 | 25 | 80.00% | 0 |
| V3.10 published, Coverage ON | Tradona | 513.87 | 31.67% | 1.28 | 220 | 51.82% | 0 |
| C-C01 | Tradona | 204.28 | 10.08% | 5.04 | 23 | 73.91% | 0 |

Direct answers:

- Versus V3.00, C-C01 Net is `+3.26 USD` FxPro and `+150.41 USD` Tradona. FxPro DD is `0.16` points higher, while Tradona DD is `0.21` points lower. PF improves by `0.08` and `2.97`; trades are unchanged/+1; win rate is unchanged/+1.18 points.
- Versus V3.10 published, C-C01 Net is lower by `417.66 USD` FxPro and `309.59 USD` Tradona, and trades are lower by `198/197` because Coverage orders were removed.
- C-C01 DD is lower than V3.10 by `29.40` points FxPro and `21.59` points Tradona. PF improves by `1.90/3.76`, and win rate improves by `25.29/22.09` points.
- Under the locked order, V3.10 wins raw Net and opportunity count, but its `31.67% to 38.88%` drawdown triggers the DD veto. Its forced Coverage design also violates the current core-SOP-only comparison basis. It remains the historical Net / Opportunity benchmark, not Current Champion.
- C-C01 is promoted for the better validated profit-versus-drawdown balance, both-broker TRAIN/OOS positivity and zero rejects. It does not claim to beat V3.10 on raw Net.

The three isolated comparisons use strict same-period clean references in [HISTORICAL_REFERENCE_AUDIT_2026-08-31.md](../reference/HISTORICAL_REFERENCE_AUDIT_2026-08-31.md). The published Combined source rows are preserved in the final evidence package and are summarized in [FINAL_CHAMPION_VS_V300_V310.csv](../reference/FINAL_CHAMPION_VS_V300_V310.csv).

## Strategy contribution

The per-strategy rows below use closed trade attribution from the Combined run. Max Equity DD is an account-level MT5 metric and cannot be exactly decomposed by magic number while positions overlap, so it is not fabricated here.

| Segment | Broker | Strategy | Net USD | PF | Trades | Win Rate | Reject |
|---|---|---|---:|---:|---:|---:|---:|
| FULL 2026 | FxPro | Scalping | 64.39 | 2.55 | 20 | 75.00% | 0 |
| FULL 2026 | FxPro | Intraday | 28.66 | N/A, no gross loss | 4 | 100.00% | 0 |
| FULL 2026 | FxPro | Swing | 0.66 | N/A, no gross loss | 1 | 100.00% | 0 |
| FULL 2026 | Tradona | Scalping | 28.03 | 1.55 | 17 | 64.71% | 0 |
| FULL 2026 | Tradona | Intraday | 28.33 | N/A, no gross loss | 4 | 100.00% | 0 |
| FULL 2026 | Tradona | Swing | 147.92 | N/A, no gross loss | 2 | 100.00% | 0 |
| LONG100 | Tradona | Scalping | 53.47 | 1.72 | 27 | 66.67% | 0 |
| LONG100 | Tradona | Intraday | 94.60 | 8.88 | 16 | 93.75% | 0 |
| LONG100 | Tradona | Swing | 169.09 | N/A, no gross loss | 7 | 100.00% | 0 |

## Portfolio audit

Tradona LONG100 net and trades are exactly additive:

- independent net: `53.47 + 94.60 + 169.09 = 317.16 USD`;
- Combined net: `317.16 USD`;
- independent trades: `27 + 16 + 7 = 50`;
- Combined trades: `50`;
- Combined Max Equity DD: `8.50%`, below the largest independent line's `9.84%`.

FxPro FULL is also exactly additive at `93.71 USD` and `25` trades. Tradona FULL differs by only `+0.26 USD`, caused by tick-level management timing around the same Swing positions, with no lost trade.

Across the eight overlapping test reports there were `167` order requests, `167` fills and `0` broker rejects. One Swing setup in Tradona TRAIN2025 was blocked before order request by the `10%` total-risk cap; LONG100 includes the same historical event. The isolated SW-W37 run blocks the same setup, so this is not a new portfolio interaction.

`C-C02` and `C-C03` were not promoted to testing because C-C01 had no position-limit rejection, no lost trade versus the locked components and no drawdown deterioration on LONG100. Lowering concurrency would solve no observed defect and could only remove valid independent opportunities.

## Decision

`C-C01` is locked as the current Combined 3-SOP Research / Backtest Champion. It is positive in TRAIN and OOS on both brokers, has zero broker rejects, preserves the three independent Champion contributions and keeps the longest-sample account Max Equity DD at `8.50%`.

The lock is deliberately qualified:

- Swing evidence remains only `7` LONG100 trades and `1` OOS trade per broker;
- Tradona 2026 profit is strongly influenced by one high-volatility Swing winner;
- that Swing trade had `9.93%` initial SL risk at the broker minimum `0.01` lot;
- OOS account drawdown reaches `10.24%` on Tradona and `9.89%` on FxPro;
- fixed `0.01` lot does not normalize risk equally across the three SOPs;
- no forward-demo or live evidence is included;
- FxPro history starts at `2026-01-05`, so the longer sample exists only on Tradona.

Any source, EX5, SET, symbol specification or test-period change invalidates this lock until the same matrix is rerun.

## Reproducibility

- Source SHA256: `AC9826E6EF4959562B9079A1FF9B8CBB35E5E8C2A913E431488CA5C900D1FF60`
- EX5 SHA256: `CBBB0FF7EC33DE8E31ACD7711F584A01A7E027A19EB446F593BFF0DA7F1B3269`
- MetaEditor compile: `0 errors, 0 warnings`
- Account metrics: `reports/combined/COMBINED_CANDIDATE_METRICS.csv`
- Strategy attribution: `reports/combined/COMBINED_STRATEGY_METRICS.csv`
- Final package: `champion/current/`
