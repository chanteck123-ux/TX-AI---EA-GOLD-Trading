# IN-I32 Intraday M30 Champion Lock

Status: `LOCKED RESEARCH / BACKTEST CHAMPION`

Strategy: `Intraday M30`

Source: `GSM_Gold_3SOP_EA_v4.00.mq5`

Compile: `0 errors, 0 warnings`

MQ5 SHA256: `545F1F8F4E09F3A3F13076FF7FF0E6AFCD2C88C3852775807A6C9AD1545B2293`

EX5 SHA256: `470457A6A20C119884CF67D2214F64FEC8803228BCBC9EE735DBA96DAF56F2EB`

## Accepted evidence

| Segment | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| TRAIN 2025 | Tradona | 52.18 | 2.76% | 5.34 | 10 | 90.00% | 0 |
| OOS 2026 | FxPro | 14.08 | 0.74% | 177.00 | 2 | 100.00% | 0 |
| OOS 2026 | Tradona | 14.27 | 0.74% | N/A, no gross loss | 2 | 100.00% | 0 |
| FULL 2026 | FxPro | 28.66 | 1.52% | 180.13 | 4 | 100.00% | 0 |
| FULL 2026 | Tradona | 28.33 | 1.51% | N/A, no gross loss | 4 | 100.00% | 0 |
| LONG100 | Tradona | 94.60 | 2.76% | 8.88 | 16 | 93.75% | 0 |

## V3.00 / V3.10 decision

On the strict isolated FULL 2026 comparison, IN-I32 raises net and trades and lowers drawdown versus both V3.00 and clean V3.10 on both brokers. It also produces positive two-trade OOS evidence where both old versions produced zero trades. The four-trade FULL and two-trade OOS samples remain small.

The complete decision and limitations are in [INTRADAY_CHAMPION_REPORT_2026-09-02.md](../../../reports/intraday/INTRADAY_CHAMPION_REPORT_2026-09-02.md).

Every file in this directory is covered by `SHA256.csv`. Any source, EX5, SET, config or report change invalidates this lock until the full matrix is rerun.
