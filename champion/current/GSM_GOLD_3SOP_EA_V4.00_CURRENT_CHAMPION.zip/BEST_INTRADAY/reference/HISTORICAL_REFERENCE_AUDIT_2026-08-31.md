# V3.00 and V3.10 Historical Reference Audit

Audit date: 2026-08-31

Status: `REFERENCE FROZEN / NO CHAMPION PROMOTED`

## Purpose

V3.00 remains the published Quality / Stability target and V3.10 remains the published Net Profit / Opportunity target. This audit does not promote either source. It creates a second, clean comparison layer with one strategy engine ON, the other two OFF, Coverage orders OFF, fixed 0.01 lot and one total position.

## Fixed test conditions

- FxPro `GOLD` and Tradona `XAUUSD.tm`.
- USD 500, leverage 1:100.
- MT5 Model 4, every tick based on real ticks.
- TRAIN: 2026-01-05 to 2026-04-30.
- OOS: 2026-05-01 to 2026-08-26.
- FULL: 2026-01-05 to 2026-08-26.
- V3.10 Daily/Weekly Coverage: OFF.
- Reports: 36 total, 18 per Broker.

Expert hashes used by the portable terminals:

- V3.00 EX5: `EABEEAF5EFE266E3D69162FA464DD5A30B6F1C8ED82CAF5A3B245DC10AD4B83D`.
- V3.10 EX5: `FBA3528C232377227E78CF8162734F16589B4DFC36A83B221BBE1FA4000D7B3C`.

## Validation gates

All 36 reports passed:

- History quality is `100%真实报价`.
- Initial deposit is USD 500.
- Report rejected-order rows are 0.
- Allocation delta is 0.
- Unmatched exits are 0.
- Open positions at the end are 0.
- Disabled strategies produced zero trades.
- Every run has Expert, SET and report SHA256 in the external run manifest.

## FULL clean isolated reference

| Version | Strategy | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---|---:|---:|---:|---:|---:|---:|
| V3.00 | Scalping | FxPro | 64.39 | 3.10% | 2.53 | 20 | 75.00% | 0 |
| V3.00 | Scalping | Tradona | 28.03 | 3.52% | 1.55 | 17 | 64.71% | 0 |
| V3.10 | Scalping | FxPro | 64.39 | 3.10% | 2.53 | 20 | 75.00% | 0 |
| V3.10 | Scalping | Tradona | 28.03 | 3.52% | 1.55 | 17 | 64.71% | 0 |
| V3.00 | Intraday | FxPro | 24.18 | 2.36% | 605.50 | 1 | 100.00% | 0 |
| V3.00 | Intraday | Tradona | 24.07 | 2.47% | 0.00 raw | 1 | 100.00% | 0 |
| V3.10 | Intraday | FxPro | 6.28 | 2.93% | 158.00 | 1 | 100.00% | 0 |
| V3.10 | Intraday | Tradona | 6.45 | 2.90% | 0.00 raw | 1 | 100.00% | 0 |
| V3.00 | Swing | FxPro | -27.11 | 11.59% | 0.07 | 5 | 80.00% | 0 |
| V3.00 | Swing | Tradona | 82.98 | 40.33% | 1.52 | 9 | 66.67% | 0 |
| V3.10 | Swing | FxPro | -27.39 | 13.99% | 0.06 | 5 | 80.00% | 0 |
| V3.10 | Swing | Tradona | 6.70 | 43.85% | 1.03 | 9 | 55.56% | 0 |

`0.00 raw` is the exact Profit Factor displayed by the Tradona MT5 report for its single winning Intraday trade. It is preserved instead of silently replacing broker output with an inferred infinity value.

## OOS clean isolated reference

| Version | Strategy | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---|---:|---:|---:|---:|---:|---:|
| V3.00 | Scalping | FxPro | 53.83 | 2.38% | 4.23 | 12 | 83.33% | 0 |
| V3.00 | Scalping | Tradona | 18.63 | 3.14% | 1.77 | 9 | 66.67% | 0 |
| V3.10 | Scalping | FxPro | 53.83 | 2.38% | 4.23 | 12 | 83.33% | 0 |
| V3.10 | Scalping | Tradona | 18.63 | 3.14% | 1.77 | 9 | 66.67% | 0 |
| V3.00 | Intraday | FxPro | 0.00 | 0.00% | 0.00 | 0 | 0.00% | 0 |
| V3.00 | Intraday | Tradona | 0.00 | 0.00% | 0.00 | 0 | 0.00% | 0 |
| V3.10 | Intraday | FxPro | 0.00 | 0.00% | 0.00 | 0 | 0.00% | 0 |
| V3.10 | Intraday | Tradona | 0.00 | 0.00% | 0.00 | 0 | 0.00% | 0 |
| V3.00 | Swing | FxPro | -27.46 | 9.89% | 0.05 | 4 | 75.00% | 0 |
| V3.00 | Swing | Tradona | -27.81 | 9.86% | 0.04 | 4 | 75.00% | 0 |
| V3.10 | Swing | FxPro | -27.52 | 9.89% | 0.05 | 4 | 75.00% | 0 |
| V3.10 | Swing | Tradona | -27.97 | 9.86% | 0.04 | 4 | 75.00% | 0 |

## Decisions

### Scalping

V3.00 and clean V3.10 are identical in both Brokers and all segments. This logic is the strongest evidence-backed seed for the new Scalping Base, but it is not a Champion: FULL has only 20 FxPro and 17 Tradona trades, while TRAIN has seven trades per Broker and PF 1.14/1.09.

### Intraday

Both old versions generate zero TRAIN and zero OOS trades. Their separately initialized FULL run generates one trade, so the segment results are not additive and cannot establish stable out-of-sample behavior. This is insufficient for a strategy benchmark. Intraday must be rebuilt from the GSM M30 SOP rather than promoted from either old engine.

### Swing

Both versions fail OOS on both Brokers. Tradona TRAIN also has 36.29% to 39.44% equity drawdown. Neither old Swing engine is an acceptable Base Champion.

## Champion status

- Best Scalping Champion: `NONE`.
- Best Intraday Champion: `NONE`.
- Best Swing Champion: `NONE`.
- Best Combined Champion: `NONE`.

The complete 36-row evidence is in [REFERENCE_METRICS.csv](REFERENCE_METRICS.csv). Raw MT5 reports, generated SET files, configs and run manifests remain in the external research work directory and are not mislabeled as a Champion delivery.
