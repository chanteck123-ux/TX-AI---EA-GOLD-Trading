# IN-I32 Intraday M30 Champion Report

Date: `2026-09-02`

Status: `LOCKED RESEARCH / BACKTEST CHAMPION`

This lock applies only to the isolated Intraday M30 line. It is not live-trading authorization and it does not create a Combined 3-SOP Champion.

## Champion logic

- Scalping: `OFF`
- Intraday: `ON`
- Swing: `OFF`
- Trend: M30 EMA 50/200 hard direction and price-side check
- Zone: nearest GSM M30 Supply/Demand zone, departure, first touch
- RSI: closed M30 RSI as a zone mean-reversion direction gate; BUY `0..50`, SELL `50..100`
- MACD: observe only, not a hard blocker
- SL / TP: `120 / 70` course points
- Closed lower-timeframe candle confirmation: `OFF`
- Break-even: `OFF`
- ATR zone-width filter: `OFF`
- Minimum touch-depth filter: `OFF`
- Lot: fixed `0.01`
- Starting capital: `USD 500`

## Accepted evidence

Every accepted test used MT5 model `4`, `100% real quotes`, isolated Intraday execution and zero broker rejects.

| Segment | Broker | Symbol | Period | Net Profit USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| TRAIN 2025 | Tradona | XAUUSD.tm | 2025-02-01 to 2025-12-31 | 52.18 | 14.81 USD / 2.76% | 5.34 | 10 | 90.00% | 0 |
| TRAIN 2026 | FxPro | GOLD | 2026-01-05 to 2026-04-30 | 7.66 | 0.19 USD / 0.04% | 192.50 | 1 | 100.00% | 0 |
| TRAIN 2026 | Tradona | XAUUSD.tm | 2026-01-05 to 2026-04-30 | 7.00 | 0.42 USD / 0.08% | N/A, no gross loss | 1 | 100.00% | 0 |
| OOS 2026 | FxPro | GOLD | 2026-05-01 to 2026-08-26 | 14.08 | 3.72 USD / 0.74% | 177.00 | 2 | 100.00% | 0 |
| OOS 2026 | Tradona | XAUUSD.tm | 2026-05-01 to 2026-08-26 | 14.27 | 3.72 USD / 0.74% | N/A, no gross loss | 2 | 100.00% | 0 |
| FULL 2026 | FxPro | GOLD | 2026-01-05 to 2026-08-26 | 28.66 | 7.77 USD / 1.52% | 180.13 | 4 | 100.00% | 0 |
| FULL 2026 | Tradona | XAUUSD.tm | 2026-01-05 to 2026-08-26 | 28.33 | 7.68 USD / 1.51% | N/A, no gross loss | 4 | 100.00% | 0 |
| LONG100 | Tradona | XAUUSD.tm | 2025-02-01 to 2026-08-26 | 94.60 | 14.81 USD / 2.76% | 8.88 | 16 | 93.75% | 0 |

MT5 writes Profit Factor as `0` when a segment has no gross loss. Those Tradona rows are reported as `N/A, no gross loss`; they are not interpreted as PF zero.

## V3.00 / V3.10 historical benchmark

This is the clean isolated FULL comparison under the same broker, symbol, USD 500, 1:100 leverage, fixed 0.01 lot, MT5 real-tick model and `2026-01-05 to 2026-08-26` period. V3.10 Coverage was OFF.

| Version | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| V3.00 | FxPro | 24.18 | 2.36% | 605.50 | 1 | 100.00% | 0 |
| V3.10 clean | FxPro | 6.28 | 2.93% | 158.00 | 1 | 100.00% | 0 |
| IN-I32 | FxPro | 28.66 | 1.52% | 180.13 | 4 | 100.00% | 0 |
| V3.00 | Tradona | 24.07 | 2.47% | 0.00 raw, one winner | 1 | 100.00% | 0 |
| V3.10 clean | Tradona | 6.45 | 2.90% | 0.00 raw, one winner | 1 | 100.00% | 0 |
| IN-I32 | Tradona | 28.33 | 1.51% | N/A, no gross loss | 4 | 100.00% | 0 |

Direct answers:

- Net versus V3.00: `+4.48 USD` FxPro and `+4.26 USD` Tradona.
- Net versus clean V3.10: `+22.38 USD` FxPro and `+21.88 USD` Tradona.
- Max Equity DD versus V3.00 improves by `0.84` and `0.96` percentage points; versus V3.10 it improves by `1.41` and `1.39` points.
- FxPro PF is below V3.00's fragile one-trade value but above V3.10; Tradona has no gross loss. PF is not treated as statistically stable at these sample sizes.
- FULL trade count rises from `1` to `4` per broker. OOS improves from zero old-version trades to two profitable trades per broker, but the absolute sample is still small.
- Win rate remains 100% and broker rejects remain zero; this does not remove the small-sample limitation.

Source: [HISTORICAL_REFERENCE_AUDIT_2026-08-31.md](../reference/HISTORICAL_REFERENCE_AUDIT_2026-08-31.md).

## Champion comparison

The strict BASE produced more than 3,000 zones and hundreds of first touches but zero orders because the unified EMA+RSI+MACD hard stack filtered every setup. `IN-I23` removed that collapse and was the strongest earlier balance candidate, but its OOS PF was only `1.13` on both brokers.

| Segment | Broker | Version | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---|---:|---:|---:|---:|---:|---:|
| OOS | FxPro | IN-I23 | 1.66 | 3.35% | 1.13 | 3 | 66.67% | 0 |
| OOS | FxPro | IN-I32 | 14.08 | 0.74% | 177.00 | 2 | 100.00% | 0 |
| OOS | Tradona | IN-I23 | 1.59 | 3.38% | 1.13 | 3 | 66.67% | 0 |
| OOS | Tradona | IN-I32 | 14.27 | 0.74% | N/A, no gross loss | 2 | 100.00% | 0 |
| LONG100 | Tradona | IN-I23 | 84.78 | 2.90% | 3.30 | 20 | 85.00% | 0 |
| LONG100 | Tradona | IN-I32 | 94.60 | 2.76% | 8.88 | 16 | 93.75% | 0 |

`IN-I32` improves LONG100 net by `9.82 USD`, lowers drawdown by `0.14` percentage points, raises PF by `5.58`, and raises win rate by `8.75` percentage points. It also changes both-broker OOS from marginal PF `1.13` to two clean wins with substantially lower drawdown. The cost is four fewer LONG100 trades and a very small OOS sample.

## Decision

`IN-I32` is locked as the current Intraday M30 Research / Backtest Champion because it is profitable in TRAIN, both-broker OOS, both-broker FULL and the longer Tradona sample; it has zero rejects and the best current net-versus-drawdown balance.

The lock is deliberately qualified:

- only `2` OOS trades per broker;
- only `16` LONG100 trades;
- very high or loss-free PF values are mathematically valid but statistically fragile;
- no forward-demo or live evidence is included;
- FxPro history starts on `2026-01-05`, so the 2025 training extension exists only on Tradona;
- the Combined portfolio interaction has not yet been tested.

Any source, EX5, SET or test-period change invalidates this lock until the same matrix is rerun.

## Reproducibility

- Source SHA256: `545F1F8F4E09F3A3F13076FF7FF0E6AFCD2C88C3852775807A6C9AD1545B2293`
- EX5 SHA256: `470457A6A20C119884CF67D2214F64FEC8803228BCBC9EE735DBA96DAF56F2EB`
- MetaEditor compile: `0 errors, 0 warnings`
- Detailed Candidate matrix: `reports/intraday/INTRADAY_CANDIDATE_METRICS.csv`
- Locked package: `champion/intraday/current/`
