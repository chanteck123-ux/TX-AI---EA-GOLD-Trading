# SW-W37 Swing Champion

Status: `LOCKED RESEARCH / BACKTEST CHAMPION`

SW-W37 is the isolated Swing D1/H4/M30 research Champion. It combines the GSM H4 Supply/Demand first-touch workflow with H4 EMA50/200 direction, a closed M30 reversal or false-break confirmation, a chase-entry guard and volatility-aware `2R / 3R` targeting.

Headline longer-sample result:

| Broker | Period | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| Tradona | 2025-02-01 to 2026-08-26 | 169.09 | 9.84% | N/A, no gross loss | 7 | 100.00% | 0 |

Both FxPro and Tradona OOS are positive with zero rejects, but each has only one trade. FxPro TRAIN has zero trades, and one Tradona trade used `9.93%` initial SL risk at the broker minimum `0.01` lot. This is not live-trading authorization.

## V3.00 / V3.10 decision

On the strict isolated FULL 2026 comparison, SW-W37 improves net, drawdown, PF and win rate versus V3.00 and clean V3.10 on both brokers, and turns both old negative OOS results positive. FULL trade count falls from 5/9 to 1/2, so the low-sample risk remains a prominent limitation.

See `REPORTS/SWING_CHAMPION_REPORT_2026-09-03.md` and `SHA256.csv` for the complete evidence and hashes.
