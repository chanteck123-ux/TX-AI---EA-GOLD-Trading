# SW-W37 Swing Champion Report

Date: `2026-09-03`

Status: `LOCKED RESEARCH / BACKTEST CHAMPION`

This lock applies only to the isolated Swing D1/H4/M30 line. It is not live-trading authorization and it does not create a Combined 3-SOP Champion.

## Champion logic

- Scalping: `OFF`
- Intraday: `OFF`
- Swing: `ON`
- Framework: D1 bias, H4 setup zone, closed M30 reversal or false-break confirmation
- Trend: H4 EMA 50/200 hard direction and price-side check
- Zone: nearest fresh H4 Supply/Demand zone, departure, first touch
- Chase protection: reject entry beyond `0.15` of the zone width
- Base target: `2R`
- High-volatility target: `3R` when closed M30 ATR / entry price is at least `1.0%`
- Break-even: starts at `0.5R`, with `5` course-point offset
- Trailing: starts at `2R`, H4 ATR `2.0`, step `10` course points
- Lot: fixed `0.01`
- Account open-risk cap: `10%`
- Starting capital: `USD 500`

## Accepted evidence

Every accepted test used MT5 model `4`, `100% real quotes`, isolated Swing execution and zero broker rejects.

| Segment | Broker | Symbol | Period | Net Profit USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
| TRAIN 2025 | Tradona | XAUUSD.tm | 2025-02-01 to 2025-12-31 | 20.91 | 13.74 USD / 2.57% | N/A, no gross loss | 5 | 100.00% | 0 |
| TRAIN 2026 | FxPro | GOLD | 2026-01-05 to 2026-04-30 | 0.00 | 0.00 USD / 0.00% | N/A, no trades | 0 | N/A | 0 |
| TRAIN 2026 | Tradona | XAUUSD.tm | 2026-01-05 to 2026-04-30 | 147.57 | 61.36 USD / 10.18% | N/A, no gross loss | 1 | 100.00% | 0 |
| OOS 2026 | FxPro | GOLD | 2026-05-01 to 2026-08-26 | 0.66 | 47.62 USD / 8.69% | 17.50 | 1 | 100.00% | 0 |
| OOS 2026 | Tradona | XAUUSD.tm | 2026-05-01 to 2026-08-26 | 0.35 | 47.13 USD / 8.61% | N/A, no gross loss | 1 | 100.00% | 0 |
| FULL 2026 | FxPro | GOLD | 2026-01-05 to 2026-08-26 | 0.66 | 47.62 USD / 8.69% | 17.50 | 1 | 100.00% | 0 |
| FULL 2026 | Tradona | XAUUSD.tm | 2026-01-05 to 2026-08-26 | 147.66 | 61.36 USD / 10.18% | N/A, no gross loss | 2 | 100.00% | 0 |
| LONG100 | Tradona | XAUUSD.tm | 2025-02-01 to 2026-08-26 | 169.09 | 61.36 USD / 9.84% | N/A, no gross loss | 7 | 100.00% | 0 |

MT5 writes Profit Factor as `0` when a segment has no gross loss. Those rows are reported as `N/A, no gross loss`; they are not interpreted as PF zero.

## V3.00 / V3.10 historical benchmark

This is the clean isolated FULL comparison under the same broker, symbol, USD 500, 1:100 leverage, fixed 0.01 lot, MT5 real-tick model and `2026-01-05 to 2026-08-26` period. V3.10 Coverage was OFF.

| Version | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| V3.00 | FxPro | -27.11 | 11.59% | 0.07 | 5 | 80.00% | 0 |
| V3.10 clean | FxPro | -27.39 | 13.99% | 0.06 | 5 | 80.00% | 0 |
| SW-W37 | FxPro | 0.66 | 8.69% | 17.50 | 1 | 100.00% | 0 |
| V3.00 | Tradona | 82.98 | 40.33% | 1.52 | 9 | 66.67% | 0 |
| V3.10 clean | Tradona | 6.70 | 43.85% | 1.03 | 9 | 55.56% | 0 |
| SW-W37 | Tradona | 147.66 | 10.18% | N/A, no gross loss | 2 | 100.00% | 0 |

Direct answers:

- Net versus V3.00 improves by `27.77 USD` FxPro and `64.68 USD` Tradona.
- Net versus clean V3.10 improves by `28.05 USD` FxPro and `140.96 USD` Tradona.
- Max Equity DD versus V3.00 improves by `2.90` points FxPro and `30.15` points Tradona; versus V3.10 it improves by `5.30` and `33.67` points.
- PF and win rate improve on both brokers, and both old versions' negative OOS result becomes positive.
- The cost is severe sample reduction: FULL drops from `5/9` trades to `1/2` trades. This is not hidden; SW-W37 remains a low-sample Research / Backtest Champion and must not be treated as proven live robustness.
- All compared reports have zero broker rejects.

Source: [HISTORICAL_REFERENCE_AUDIT_2026-08-31.md](../reference/HISTORICAL_REFERENCE_AUDIT_2026-08-31.md).

## Champion comparison

The fair BASE used the same fixed `0.01` lot and `10%` account open-risk cap. It remained active enough to trade but lost money over the longer Tradona sample.

| Segment | Broker | Version | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---|---:|---:|---:|---:|---:|---:|
| LONG100 | Tradona | BASE | -55.10 | 17.42% | 0.06 | 15 | 60.00% | 0 |
| LONG100 | Tradona | SW-W29, fixed 2R | 120.53 | 9.69% | N/A, no gross loss | 7 | 100.00% | 0 |
| LONG100 | Tradona | SW-W32, fixed 3R | 148.12 | 10.17% | 124.43 | 7 | 85.71% | 0 |
| LONG100 | Tradona | SW-W37, volatility 2R/3R | 169.09 | 9.84% | N/A, no gross loss | 7 | 100.00% | 0 |

Against BASE, SW-W37 improves LONG100 net by `224.19 USD`, lowers max equity drawdown by `7.58` percentage points and removes all seven losing exits, at the cost of eight fewer trades. Against SW-W29 it adds `48.56 USD` with only `0.15` percentage points more drawdown and no reduction in trades or win rate.

The `0.8%`, `1.0%` and `1.2%` ATR/price thresholds produced identical TRAIN2025 and FULL results. The central `1.0%` threshold was selected to avoid locking a boundary value. The volatility module leaves ordinary 2025 setups at `2R` and assigns the exceptional March 2026 setup a `3R` target.

## Decision

`SW-W37` is locked as the current Swing Research / Backtest Champion because it is positive on the longer Tradona sample, positive on both-broker OOS, materially improves net and drawdown over BASE, and has `OrdersRequested = OrdersFilled` with zero rejects.

The lock is deliberately qualified:

- only `1` OOS trade per broker and `7` LONG100 trades;
- FxPro TRAIN has no trade, so cross-broker training symmetry is absent;
- Tradona 2026 net is dominated by one high-volatility winner;
- that trade used `49.63 USD`, or `9.93%`, initial SL risk because XAUUSD.tm minimum volume is `0.01` lot;
- the `9.84%` LONG100 max equity drawdown is acceptable for research but requires portfolio review before combination;
- no forward-demo or live evidence is included;
- FxPro history starts on `2026-01-05`, so the 2025 extension exists only on Tradona;
- the Combined portfolio interaction has not yet been tested.

Any source, EX5, SET, symbol specification or test-period change invalidates this lock until the same matrix is rerun.

## Reproducibility

- Source SHA256: `AC9826E6EF4959562B9079A1FF9B8CBB35E5E8C2A913E431488CA5C900D1FF60`
- EX5 SHA256: `CBBB0FF7EC33DE8E31ACD7711F584A01A7E027A19EB446F593BFF0DA7F1B3269`
- MetaEditor compile: `0 errors, 0 warnings`
- Detailed Candidate matrix: `reports/swing/SWING_CANDIDATE_METRICS.csv`
- Locked package: `champion/swing/current/`
