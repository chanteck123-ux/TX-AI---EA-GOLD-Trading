# Champion Backtest Protocol

## Fixed environment

| Field | FxPro | Tradona |
|---|---|---|
| Symbol | `GOLD` | `XAUUSD.tm` |
| Capital | USD 500 | USD 500 |
| Leverage | 1:100 | 1:100 |
| Model | MT5 `Model=4`, every tick based on real ticks | MT5 `Model=4`, every tick based on real ticks |
| Chart period | M5 host chart; each engine reads its own timeframe | M5 host chart; each engine reads its own timeframe |
| Execution | Broker terminal specification | Broker terminal specification |

Runtime symbol limits, volume step, stop level, filling mode, tick value, contract size, spread and commission remain broker supplied. They must be recorded from each raw report or EA initialization log; screenshots are not permanent configuration.

## Frozen dates

The first formal research cycle uses:

| Segment | From | To | Purpose |
|---|---|---|---|
| TRAIN | 2026-01-05 | 2026-04-30 | Candidate selection only |
| OOS | 2026-05-01 | 2026-08-26 | Frozen validation; no retuning |
| FULL | 2026-01-05 | 2026-08-26 | Reporting and historical target comparison |

OOS data may be read only after the Candidate and parameters are frozen. Any change made after reading OOS creates a new Candidate and requires a new untouched OOS segment before Champion promotion.

## Historical references

Two types of references are kept separate:

1. Historical Published Reference: the original V3.00 and V3.10 combined reports, including their original limitations.
2. Clean Isolated Reference: V3.00 and V3.10 logic rerun with one engine ON, the other two OFF, fixed 0.01 lot, one total open position, Coverage order generation OFF, and identical dates/capital/model.

The Clean Isolated Reference does not certify either old version as Champion. It exists only to provide fair per-strategy target evidence.

## Candidate gates

Every single-strategy result must prove:

- Other two engines are OFF.
- Compile result is 0 errors and 0 warnings for the exact EX5.
- Coverage/reporting routines cannot call the order path.
- Raw report history quality is 100% real ticks.
- Report and SET identify Broker, Symbol, Segment and Candidate.
- Net USD, Max Equity DD, PF, Trades, Win Rate and Reject are present.
- Signal funnel, loss audit and missed-entry audit identify where signals stopped.
- Reject is 0.

Every Champion promotion additionally requires FxPro and Tradona OOS directionally consistent results and a documented comparison against V3.00, V3.10 and the previous strategy Champion.

## Portfolio gates

Combined testing additionally audits concurrent exposure, total risk, same-direction stacking, opposite signals, margin, netting/hedging behavior, strategy correlation and drawdown overlap. Independent profits may never be summed and presented as a Combined backtest.
