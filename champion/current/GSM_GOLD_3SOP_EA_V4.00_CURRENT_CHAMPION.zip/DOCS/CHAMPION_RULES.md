# Champion Rules

## Current status

- Scalping Champion: `SC-S20`，锁定研究 Champion；详见 `reports/scalping/SCALPING_CHAMPION_REPORT_2026-09-02.md`。
- Intraday Champion: `IN-I32`，锁定研究/回测 Champion；详见 `reports/intraday/INTRADAY_CHAMPION_REPORT_2026-09-02.md`。
- Swing Champion: `SW-W37`，锁定研究/回测 Champion；详见 `reports/swing/SWING_CHAMPION_REPORT_2026-09-03.md`。
- Combined 3-SOP Champion: `C-C01`，锁定研究/回测 Champion；详见 `reports/combined/COMBINED_CHAMPION_REPORT_2026-09-03.md`。
- V3.00: 历史参考，当前制度下仍需源码复核。
- V3.20: `REJECT / NO NEW CHAMPION`。
- 2026-08-31 全版本审计：`CURRENT CHAMPION = NONE`。V3.00 仅为历史参考；V3.10 因强制 Coverage 下单、PF/回撤及 OOS 缺口而不合格。详见 [CURRENT_CHAMPION_AUDIT_2026-08-31.md](CURRENT_CHAMPION_AUDIT_2026-08-31.md)。

## Non-negotiable gates

1. MetaEditor 编译必须 `0 errors, 0 warnings`。
2. 三策略必须 OR 独立执行，各自有开关、Magic、SOP 和漏斗。
3. Frequency Audit、Coverage 和报告逻辑不得创建订单。
4. Confidence 第一阶段必须 score/display/log only，除非 Candidate 明确测试评分门禁。
5. 回测模型必须是 `Every tick based on real ticks`。
6. 基础资金 USD 500，FxPro 和 Tradona 都要验证。
7. Broker order reject 必须为 0；若非 0，先修执行层再评价策略。
8. Train 和 OOS 必须物理或配置隔离。训练期通过、OOS 失败，一律 REJECT。
9. 当前研究最低 PF 门槛是 `1.50`。少量交易产生的高 PF 不能自动通过。
10. 必须报告 Net USD、Max Equity DD、PF、Trades、Win Rate、Reject，且顺序固定如此。
11. 必须保存信号漏斗、亏损分类、漏单审计、SET、INI、原始 MT5 报告和源码提交号。
12. 不得因加入新模块造成交易数无解释坍缩或零交易。

## Evaluation order

Champion 与 Candidate 的主要比较顺序：

1. Net Profit USD。
2. Max Equity Drawdown。
3. Profit Factor。
4. Trades。
5. Win Rate。
6. Reject 必须为 0，否则先修执行层。

DD 即使排第二，仍有风险否决权。更高 Net 不能自动覆盖不可接受的 DD。PF 很高但交易数很少也不能自动晋级。

每次必须输出 `Delta Net`、`Delta Max Equity DD`、`Delta PF`、`Delta Trades` 和 `Delta Win Rate`。

## Four independent champions

- Scalping Candidate 只开启 Scalping，关闭 Intraday/Swing，只与 Current Scalping Champion 比较。
- Intraday Candidate 只开启 Intraday，关闭 Scalping/Swing，只与 Current Intraday Champion 比较。
- Swing Candidate 只开启 Swing，关闭 Scalping/Intraday，只与 Current Swing Champion 比较。
- 三个独立 Champion 均确定后才建立 Combined Candidate；组合结果必须重新回测，不能相加推断。

Candidate 编号使用 `SC-Sxx`、`IN-Ixx`、`SW-Wxx`、`COMBINED-Cxx`。GitHub Research 的 `V3.21-GHxx` 是 Idea 来源编号，不等于已实现 Candidate。

## Promotion decision

单策略 Candidate 只有在两个经纪商 OOS 都通过门禁，并按 Net、DD、PF、Trades、Win Rate 综合优于对应策略 Champion 时，才可提出 `NEW STRATEGY CHAMPION`。

任一单策略 Champion 更新后，必须与另外两个锁定 Champion 重新组成 Combined Candidate。组合后必须审计并发仓位、保证金、总风险、同向暴露、对向信号和回撤重叠；只有组合 OOS 也通过，才可提出 `NEW 3-SOP CHAMPION`。

单一平台、单一短样本、README 宣称或把三个单独成绩直接相加，都不能升级 Champion。

在新的认证 Champion 出现前，比较表必须同时显示 V3.00 历史参考和 V3.20 当前研究基线，不得把任何一方写成已认证实盘版本。
