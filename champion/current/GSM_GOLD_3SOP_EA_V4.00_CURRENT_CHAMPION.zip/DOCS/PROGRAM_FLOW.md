# 3-SOP Program Flow

## Initialization

`OnInit` 必须检查：品种映射、Volume Min/Max/Step、Tick Size/Value、Stops/Freeze Level、Filling Mode、点差单位、Course Pips/PT 换算、时段、评分最高可达值、权重、News Lock、First Touch 状态转换和三个策略开关。

初始化失败必须返回错误，并在日志和图表信息面板显示具体原因。

## Tick flow

```text
OnTick
  -> refresh broker symbol specification
  -> manage existing positions and profit protection
  -> detect new M5/M30/M30-entry bars
  -> update S&D lifecycle and closed-bar signals
  -> SCALPING enabled AND new M5 bar -> RunScalpingM5
  -> INTRADAY enabled -> MonitorIntradayM30FirstTouch
  -> SWING enabled AND new entry bar -> RunSwingD1
  -> update panel, audit, funnel, persistent state
```

Scalping、Intraday、Swing 三条路径是 OR。任何策略不得等待另外两条策略同时成立。

## Zone lifecycle

```text
FRESH -> DEPARTED -> FIRST_TOUCH -> ENTRY_PENDING -> USED
                         |                |
                         +-> BROKEN       +-> RELEASED when policy allows
```

同一 ZoneID 的 First Touch 必须原子化。一次闭合 K 线触碰只能计一次；重复 tick、重复 bar 扫描和重启恢复不得重复计数或重复下单。

## Signal funnel

每个策略独立维护：

`ZonesDetected, ZonesDeparted, FirstTouches, CandlePatternsDetected, ChartPatternsDetected, HardSOPPassed, ConfidencePassed, GlobalGatePassed, OrdersRequested, OrdersFilled, OrdersRejected`

回测结束必须逐策略打印。零成交时，诊断必须指出第一个归零层。

## Candidate flow

```text
GitHub Idea -> Research Library -> choose one affected strategy
-> SC-Sxx / IN-Ixx / SW-Wxx branch -> change one main variable
-> enable only that strategy -> MetaEditor 0/0
-> Train -> frozen OOS -> FxPro -> Tradona
-> Net -> Max Equity DD -> PF -> Trades -> Win Rate
-> compare with same-strategy Champion -> REJECT or NEW STRATEGY CHAMPION
```

若产生 New Strategy Champion：

```text
lock the other two Strategy Champions
-> build COMBINED-Cxx Combined Candidate
-> full dual-broker Real Tick and portfolio audit
-> per-strategy plus Combined metrics
-> REJECT or NEW 3-SOP COMBINED CHAMPION
-> Champion ZIP -> user delivery -> GitHub current/history
```

单策略独立回测与 Combined 回测必须分别保存。Combined 中的策略 DD 不得用单策略 DD 代替。
