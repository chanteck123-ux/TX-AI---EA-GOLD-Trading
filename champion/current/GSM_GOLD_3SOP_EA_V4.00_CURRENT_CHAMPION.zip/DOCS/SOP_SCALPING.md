# SOP: Scalping M5

## Base SOP

1. 只在 M5 执行。
2. 找最近的 Fresh Supply/Demand 区域。
3. 区域必须已经发生有效 Departure。
4. 只处理原子化 First Touch，不允许同一 ZoneID 重复开仓。
5. 回踩 K 线收盘后，必须出现方向一致的 Scalping 反转 K 白名单或清晰 Wick Rejection。
6. 合格后立即入场。
7. 固定 `SL 50 Course Pips`，固定 `TP 50 Course Pips`。

八种图表结构不是硬条件。其他蜡烛形态不是“全部满足”，同方向任一合格白名单形态即可。

## Optimization only

EMA、RSI、Stochastic、Bollinger、ATR、VWAP、Volume、时间过滤和 Confidence Filter 都是独立 Candidate 模块。默认不得因评分阻止 Base SOP 开仓。

## Required funnel

`ZonesDetected -> ZonesDeparted -> FirstTouches -> CandlePatternsDetected -> HardSOPPassed -> ConfidencePassed -> GlobalGatePassed -> OrdersRequested -> OrdersFilled/OrdersRejected`

还必须记录 `ChartPatternsDetected`，但它不是 Scalping 统一硬条件。

## V3.20 implementation snapshot

当前源码用 M5 Fresh/Departed/First Touch 状态机，硬条件是反转 K 白名单或 Wick Rejection，SL/TP 为 50/50。研究指标默认 OFF，Confidence 为 score-only。
