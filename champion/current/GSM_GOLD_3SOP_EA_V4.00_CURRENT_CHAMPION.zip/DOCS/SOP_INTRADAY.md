# SOP: Intraday M30

## Base SOP

1. 只在 M30 建立 Intraday 方向和 Setup。
2. 确认 M30 Trend。
3. 识别 M30 Supply/Demand 区域。
4. 使用 30-point Zone/Entry Location 规则。
5. 价格进入有效区域并满足 First Touch/Retest 状态后才产生核心机会。
6. 固定 `SL 120 PT`，固定 `TP 240 PT`。

图表结构和蜡烛形态默认只加分，不是统一硬条件。任何单个方向一致的合格形态可以产生识别结果，不要求同时出现多种形态。

## Candidate modules

M15、M5、Any 2 of 3、3 of 3、EMA、RSI、CCI、MACD、PPO、SMC、ATR、VWAP、Volume、动态止损和 Session Filter 都必须逐项独立测试。

## Current audit question

V3.20 的 `HardSOPPassed` 当前由允许的 S&D Formation 与 First Touch 路径推进。下一次修改前必须审计 M30 Trend 是否被独立、可观察地表达，不能把 Zone 方向自动当成已经通过 Trend Gate。

## Primary weaknesses

- `WRONG_TREND`
- `SL_TOO_TIGHT`
- `LATE_ENTRY`
