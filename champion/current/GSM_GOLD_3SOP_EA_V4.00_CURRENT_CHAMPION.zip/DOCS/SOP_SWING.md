# SOP: Swing D1/H4/M30

## Base SOP

1. D1 提供主要 Framework 和方向。
2. H4 Trend 不得与 D1 冲突。
3. 找到顺方向的 Fresh H4 Supply/Demand Setup。
4. H4 Support/Resistance 用作区域质量与边界共振，不要求八种图表结构同时出现。
5. 等待价格 Pullback 到 H4 Setup。
6. M30 必须出现方向一致的反转 K，或假突破后收回。两者是 OR，不是 AND。
7. SL 放在 H4 S&D/S&R 合并区域外，再加 Buffer。
8. 预期收益风险至少 `2:1`。

## Profit protection

- 允许 Break Even。
- 允许 ATR Trailing 或 H4 Structure Trailing。
- Trailing 只能向有利方向移动，必须遵守 Tick Size、Stops Level 和 Freeze Level。
- 保护利润不能用未来 K 线或当前未收盘信号。

## Low-frequency rule

Swing 交易数低时，先审计各漏斗层和确认窗口。Frequency Audit 只能记录机会，绝不创建强制订单。

## V3.20 implementation snapshot

当前设置使用 D1 bias、H4 setup、M30 entry；M30 反转 K或假突破确认；SL 在合并区域远端加 20 Course Pips；Break Even 默认 1R，H4 Structure Trailing 默认 2R 启动；固定 TP 默认关闭。
