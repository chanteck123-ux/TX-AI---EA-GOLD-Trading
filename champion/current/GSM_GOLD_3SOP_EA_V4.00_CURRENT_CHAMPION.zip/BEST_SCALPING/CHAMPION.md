# SC-S20 Scalping Champion Lock

Status: `LOCKED RESEARCH CHAMPION`

Strategy: `Scalping M5`

Source: `GSM_Gold_3SOP_EA_v4.00.mq5`

Compile: `0 errors, 0 warnings`

MQ5 SHA256: `3290A0A13F740F93EB0FD2781211E4D6B2DE9A21D4AC25724687B86FC926627B`

EX5 SHA256: `5C5785EC766DB65746AC3B499DA4993EB33084320F964ACDA607045041EA4035`

## Accepted evidence

| Segment | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| TRAIN 2025 | Tradona | 25.44 | 3.50% | 2.06 | 10 | 70.00% | 0 |
| OOS 2026 | FxPro | 64.39 | 3.10% | 2.53 | 20 | 75.00% | 0 |
| OOS 2026 | Tradona | 28.03 | 3.52% | 1.55 | 17 | 64.71% | 0 |
| LONG100 | Tradona | 53.47 | 3.35% | 1.72 | 27 | 66.67% | 0 |

## V3.00 / V3.10 decision

On the strict isolated FULL 2026 comparison, SC-S20 is exactly equal to V3.00 and clean V3.10 on both brokers. It is locked because the added H4 SELL regime repairs the longer Tradona 2025 failure without removing any accepted 2026 trade, not because of an invented common-period gain. The 17 to 20 trade FULL sample remains limited.

The complete decision and limitations are in [SCALPING_CHAMPION_REPORT_2026-09-02.md](../../../reports/scalping/SCALPING_CHAMPION_REPORT_2026-09-02.md).

Every file in this directory is covered by [SHA256.csv](SHA256.csv). Any source, EX5, SET, config or report change invalidates this lock until the complete matrix is rerun.
