# Scalping M5 Champion Report

Decision date: 2026-09-02

Decision: `NEW SCALPING CHAMPION = SC-S20`

SC-S20 keeps the GSM M5 entry engine unchanged and adds one optional Gold-specific regime rule: BUY setups continue to use the Base SOP, while SELL setups require a closed H4 EMA 50/200 bearish regime. Intraday and Swing were disabled in every report below.

## Champion metrics

Metric order follows the locked governance order: Net Profit, Max Equity DD, PF, Trades, Win Rate, Reject.

| Evidence segment | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| TRAIN 2025-02-01 to 2025-12-31 | Tradona XAUUSD.tm | 25.44 | 17.79 / 3.50% | 2.06 | 10 | 70.00% | 0 |
| Cross-broker OOS 2026-01-05 to 2026-08-26 | FxPro GOLD | 64.39 | 15.95 / 3.10% | 2.53 | 20 | 75.00% | 0 |
| Cross-broker OOS 2026-01-05 to 2026-08-26 | Tradona XAUUSD.tm | 28.03 | 18.18 / 3.52% | 1.55 | 17 | 64.71% | 0 |
| LONG100 2025-02-01 to 2026-08-26 | Tradona XAUUSD.tm | 53.47 | 18.18 / 3.35% | 1.72 | 27 | 66.67% | 0 |

All four reports show `100%真实报价`, USD 500, leverage 1:100 and fixed 0.01 lot. The signal funnel has `OrdersRequested = OrdersFilled` and `OrdersRejected = 0` in every accepted segment.

## V3.00 / V3.10 historical benchmark

The table below uses the clean isolated FULL reference with the same broker, symbol, USD 500, 1:100 leverage, fixed 0.01 lot, MT5 real-tick model and `2026-01-05 to 2026-08-26` period. V3.10 Coverage was OFF. This is the strict fair comparison required before Champion lock.

| Version | Broker | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| V3.00 | FxPro | 64.39 | 3.10% | 2.53 | 20 | 75.00% | 0 |
| V3.10 clean | FxPro | 64.39 | 3.10% | 2.53 | 20 | 75.00% | 0 |
| SC-S20 | FxPro | 64.39 | 3.10% | 2.53 | 20 | 75.00% | 0 |
| V3.00 | Tradona | 28.03 | 3.52% | 1.55 | 17 | 64.71% | 0 |
| V3.10 clean | Tradona | 28.03 | 3.52% | 1.55 | 17 | 64.71% | 0 |
| SC-S20 | Tradona | 28.03 | 3.52% | 1.55 | 17 | 64.71% | 0 |

Direct answers:

- Net versus V3.00: no change on either broker.
- Net versus clean V3.10: no change on either broker.
- Max Equity DD, PF, trades and win rate: also unchanged in the common FULL interval.
- SC-S20 is therefore not promoted on a fabricated 2026 performance gain. Its added value is the longer Tradona 2025/2026 evidence: the asymmetric H4 SELL regime repairs the earlier SELL failure while preserving every accepted 2026 trade.
- Trade count remains limited at 20 FxPro and 17 Tradona FULL trades, so this is a Research / Backtest Champion, not a statistically mature or live Champion.

Source: [HISTORICAL_REFERENCE_AUDIT_2026-08-31.md](../reference/HISTORICAL_REFERENCE_AUDIT_2026-08-31.md).

## Base comparison

| Segment | Candidate | Net USD | Max Equity DD | PF | Trades | Win Rate | Reject |
|---|---|---:|---:|---:|---:|---:|---:|
| Tradona TRAIN 2025 | BASE | -41.86 | 63.29 / 12.14% | 0.60 | 22 | 40.91% | 0 |
| Tradona TRAIN 2025 | SC-S20 | 25.44 | 17.79 / 3.50% | 2.06 | 10 | 70.00% | 0 |
| FxPro OOS 2026 | BASE | 64.39 | 15.95 / 3.10% | 2.53 | 20 | 75.00% | 0 |
| FxPro OOS 2026 | SC-S20 | 64.39 | 15.95 / 3.10% | 2.53 | 20 | 75.00% | 0 |
| Tradona OOS 2026 | BASE | 28.03 | 18.18 / 3.52% | 1.55 | 17 | 64.71% | 0 |
| Tradona OOS 2026 | SC-S20 | 28.03 | 18.18 / 3.52% | 1.55 | 17 | 64.71% | 0 |
| Tradona LONG100 | BASE | -13.83 | 65.25 / 12.51% | 0.91 | 39 | 51.28% | 0 |
| Tradona LONG100 | SC-S20 | 53.47 | 18.18 / 3.35% | 1.72 | 27 | 66.67% | 0 |

LONG100 delta: Net `+67.30 USD`, Max Equity DD `-9.16 percentage points`, PF `+0.81`, Trades `-12`, Win Rate `+15.39 percentage points`.

## Candidate history

- SC-S01 to SC-S03: Stochastic hard filters, rejected for lower Net/PF and trade-count collapse.
- SC-S04 to SC-S06: early break-even variants, rejected for cross-broker divergence or lower Net/PF.
- SC-S07 to SC-S10: TP/SL variants; SC-S09 improved TRAIN but failed OOS, all rejected.
- SC-S11 to SC-S13: EMA/RSI hard-filter removal, rejected for higher DD, near-one PF or cross-broker failure.
- SC-S14 to SC-S16: faster M5 EMA variants; SC-S15 passed initial OOS but failed FULL, rejected.
- SC-S17 to SC-S19: symmetric H1/H4/D1 regime filters fixed 2025 but removed profitable 2026 BUY setups, rejected.
- SC-S20: asymmetric H4 regime preserved all accepted 2026 Base trades and repaired the 2025 SELL failure; promoted.

The complete 57-row evidence table is [SCALPING_CANDIDATE_METRICS.csv](SCALPING_CANDIDATE_METRICS.csv).

## Locked parameters

- M5 nearest fresh Supply/Demand, departure, First Touch and closed reversal candle whitelist remain the core entry SOP.
- Fixed SL 80 course pips; fixed TP 70 course pips.
- M5 EMA 30/100 and RSI 14 Base filters remain enabled.
- Stochastic and break-even candidates remain OFF.
- H4 regime is ON with EMA 50/200.
- BUY is always allowed to continue through the Base SOP.
- SELL additionally requires H4 EMA50 below EMA200.
- Confidence remains score/display/log only; it does not block the Base SOP.
- Fixed lot 0.01 for the USD 500 comparison matrix.

## Compile and identity

- MetaEditor: `0 errors, 0 warnings`.
- MQ5 SHA256: `3290A0A13F740F93EB0FD2781211E4D6B2DE9A21D4AC25724687B86FC926627B`.
- EX5 SHA256: `5C5785EC766DB65746AC3B499DA4993EB33084320F964ACDA607045041EA4035`.
- FxPro SET SHA256: `735D6056615D5FE65FF5ABEEC15A3BF476C764C6C9FF87A4A4FD5AF424D59197`.
- Tradona SET SHA256: `ADD3F6B63E4D9761D4C55E93519DDF546A0CE7E3B7E1D89162C0AA88B552826E`.
- Locked evidence manifest: `champion/scalping/current/SHA256.csv`.

## Limitations

- FxPro only provides strict 100% GOLD real ticks from 2026-01-05 in the available terminal; the longer TRAIN segment is therefore Tradona-only.
- The accepted samples are moderate, not large: 10 TRAIN trades, 20/17 cross-broker OOS trades and 27 LONG100 trades.
- The 2026 validation interval was used iteratively during Candidate research. SC-S20 still requires fresh Demo forward validation after 2026-08-26 before any live-capital decision.
- Backtest performance is not a profit guarantee and this lock does not authorize live trading.
